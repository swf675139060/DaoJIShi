# countDown
# 欢迎关注我的斗鱼直播间，用手机斗鱼TV，直接搜索“文明直播间”或者“极端恐惧”就可以找到我的直播。iOS技术分享直播。进来点一下关注，谢谢，开播会有推送到大家手机。（个人直播，非机构，适合初级iOS和中级iOS）。
iOS倒计时，显示 天、时、分、秒。比如：离活动结束还有 0天 01: 14: 59

![image](https://github.com/zhengwenming/countDown/blob/master/倒计时/countDown.gif)

iOS倒计时，显示 天、时、分、秒。比如：离活动结束还有   0天 01: 14: 59



#欢迎加入iOS开发技术支持群，479259423
